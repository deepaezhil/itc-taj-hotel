<!DOCTYPE html>
<html>

<head>
    <title>Admin | ITC Taj | Bangalore</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">ITC Taj Hotel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="login.php">Admin</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="jumbotron">
            <div class="card">
                <div class="card-header">
                    <h5>Room Reserved Details</h5>
                </div>
                <div class="card-body">
                    <h5 class="card-title"></h5>
                    <?php
                $connection = mysqli_connect("localhost","root","");
                $db = mysqli_select_db($connection, 'taj_hotel');

                $query = "SELECT * FROM room_reservation";
                $query_run = mysqli_query($connection, $query);
            ?>
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Title</th>
                                <th scope="col">Name</th>
                                <th scope="col">contact</th>
                                <th scope="col">Email</th>
                                <th scope="col">Nationality</th>
                                <th scope="col">Room Type</th>
                                <th scope="col">Bed Type</th>
                                <th scope="col">Meal Plan</th>
                                <th scope="col">Check-In</th>
                                <th scope="col">Check-Out</th>
                            </tr>
                        </thead>
                        <?php
                if($query_run)
                {
                    foreach($query_run as $row)
                    {
            ?>
                        <tbody>
                            <tr>
                                <td> <?php echo $row['title']; ?> </td>
                                <td> <?php echo $row['name']; ?> </td>
                                <td> <?php echo $row['contact']; ?> </td>
                                <td> <?php echo $row['email']; ?> </td>
                                <td> <?php echo $row['nationality']; ?> </td>
                                <td> <?php echo $row['room_type']; ?> </td>
                                <td> <?php echo $row['bed_type']; ?> </td>
                                <td> <?php echo $row['meal_plan']; ?> </td>
                                <td> <?php echo $row['cin']; ?> </td>
                                <td> <?php echo $row['cout']; ?> </td>
                            </tr>
                        </tbody>
                        <?php           
                    }
                }
                else 
                {
                    echo "No Record Found";
                }
            ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1>ITC Taj Hotel</h1>
                <p>Experience the Best Luxury Lifestyle</p>
            </div>
            <div class="footer-items">
                <h1>Quick Links</h1>
                <div class="border"></div>
                <ul>
                    <a href="index.php">
                        <li>Home</li>
                    </a>
                    <a href="about.php">
                        <li>About</li>
                    </a>
                    <a href="contact.php">
                        <li>Contact</li>
                    </a>
                </ul>
            </div>

            <div class="footer-items">
                <h1>Important Links</h1>
                <div class="border"></div>
                <ul>
                    <a href="services.php">
                        <li>Services</li>
                    </a>
                    <a href="login.php">
                        <li>Admin</li>
                    </a>
                </ul>
            </div>

            <div class="footer-items">
                <h1>Contact Us</h1>
                <div class="border"></div>
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                        Taj MG Road, Bengaluru, 41/3, Mahatma Gandhi Rd, Yellappa
                        Garden, Yellappa Chetty Layout, Sivanchetti Gardens, Bengaluru, Karnataka-560001
                    </li><br><br><br><br>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>+91-9779776365</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@itctajbangalore.com</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            Copyright &copy; ITC Taj Bangalore 2021. All rights reserved. Designed by E DEEPA
        </div>
    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>