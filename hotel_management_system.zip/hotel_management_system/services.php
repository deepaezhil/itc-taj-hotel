<!DOCTYPE html>
<html>

<head>
    <title>Services at ITC Taj | Bangalore</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/services.css">
    <link rel="stylesheet" type="text/css" href="css/rooms.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <style>

    </style>
</head>

<body style="background-color: #00004D;">
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">ITC Taj Hotel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Admin</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
    </header>

    <section class="wrapper">
        <h1 style="text-align:center">
            Our Services
        </h1>
        <div class="container">
            <div class="row">
                <div class="col-lx-3 col-lg-3 col-md-6 col-sm-12 col-12">
                    <div class="service_box">
                        <div class="service_content">
                            <h3 class="title">Stay First, Pay After!</h3>
                            <p class="description">Temporibus autem quibusdam et aut officiis debitis aut rerum
                                necessitatibus saepe eveniet
                                ut et voluptates.</p>
                            <div class="service_icon">
                                <span>
                                    <i class="fa fa-credit-card" aria-hidden="true"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lx-3 col-lg-3 col-md-6 col-sm-12 col-12">
                    <div class="service_box blue">
                        <div class="service_content">
                            <h3 class="title">24 Hour Available</h3>
                            <p class="description">Temporibus autem quibusdam et aut officiis debitis aut rerum
                                necessitatibus saepe eveniet
                                ut et voluptates.</p>

                            <div class="service_icon">
                                <span>
                                    <i class="fa fa-clock-o" aria-hidden="true"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lx-3 col-lg-3 col-md-6 col-sm-12 col-12">
                    <div class="service_box purple">
                        <div class="service_content">
                            <h3 class="title">Flexible Facility</h3>
                            <p class="description">Temporibus autem quibusdam et aut officiis debitis aut rerum
                                necessitatibus saepe eveniet
                                ut et voluptates.</p>

                            <div class="service_icon">
                                <span>
                                    <i class="fa fa-wifi" aria-hidden="true"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lx-3 col-lg-3 col-md-6 col-sm-12 col-12">
                    <div class="service_box green">
                        <div class="service_content">
                            <h3 class="title">Safety And Secure</h3>
                            <p class="description">Temporibus autem quibusdam et aut officiis debitis aut rerum
                                necessitatibus saepe eveniet
                                ut et voluptates.</p>

                            <div class="service_icon">
                                <span>
                                    <i class="fa fa-lock" aria-hidden="true"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </br>
    </br>
    </br>
    <section class="room">
        <form action="reservation.php" method="POST">
            <div class="container">
                <h1 style="text-align:center">Rooms</h1>
                <div class="card">
                    <img src="images/room1.jpg" alt="Deluxe Room" style="width:100%">
                    <h1>Deluxe Room</h1>
                    <p class="price">Rs.5000</p>
                    <p>

                        <button type="submit" name="book">BOOK</button>

                    </p>
                </div>
                <div class="card">
                    <img src="images/room2.jpg" alt="Luxury Room" style="width:100%">
                    <h1>Luxury Room</h1>
                    <p class="price">Rs.3000</p>
                    <p>

                        <button type="submit" name="book">BOOK</button>

                    </p>
                </div>
                <div class="card">
                    <img src="images/room3.jpg" alt="Guest House" style="width:100%">
                    <h1>Guest House</h1>
                    <p class="price">Rs.2500</p>
                    <p>

                        <button type="submit" name="book">BOOK</button>

                    </p>
                </div>
                <div class="card">
                    <img src="images/room4.jpg" alt="Single Room" style="width:100%">
                    <h1>Single Room</h1>
                    <p class="price">Rs.1000</p>
                    <p>

                        <button type="submit" name="book">BOOK</button>

                    </p>
                </div>
            </div>
            <form>
    </section>

    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1>ITC Taj Hotel</h1>
                <p>Experience the Best Luxury Lifestyle</p>
            </div>
            <div class="footer-items">
                <h1>Quick Links</h1>
                <div class="border"></div>
                <ul>
                    <a href="index.php">
                        <li>Home</li>
                    </a>
                    <a href="about.php">
                        <li>About</li>
                    </a>
                    <a href="contact.php">
                        <li>Contact</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Important Links</h1>
                <div class="border"></div>
                <ul>

                    <a href="services.php">
                        <li>Services</li>
                    </a>
                    <a href="login.php">
                        <li>Admin</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Contact Us</h1>
                <div class="border"></div>
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                        Taj MG Road, Bengaluru,
                        41/3,
                        Mahatma
                        Gandhi
                        Rd,
                        Yellappa
                        Garden, Yellappa Chetty Layout, Sivanchetti Gardens,
                        Bengaluru,
                        Karnataka-560001
                    </li><br><br><br><br>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>+91-9779776365
                    </li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@itctajbangalore.com
                    </li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            Copyright &copy; ITC Taj Bangalore 2021. All rights reserved. Designed
            by E
            DEEPA
        </div>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
    </script>

</body>

</html>