<!DOCTYPE html>
<html>

<head>
    <title>Services at ITC Taj | Bangalore</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    $(function() {
        $("#datepicker").datepicker();
    });
    </script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/reservation.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">ITC Taj Hotel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Admin</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <div class="container">


        <form class="form-group" action="reservation.php" method="POST">

            <h1 class="text-center">Room Reservation Form</h1>

            <div id="form">

                <h3 class="text-white">Booking Details</h3>

                <div id="input">

                    <label for="datepicker" id="input-group">Check-In</label>
                    <input type="date" name="cin" id="datepicker">
                    <label for="datepicker" id="input-group">Check-Out</label>
                    <input type="date" name="cout" id="datepicker">

                </div>


                <div id="input2">

                    <select id="input-group" name="room_type" style=" background: black;">
                        <option value="">Preffered Room Type</option>
                        <option value="Deluxe Room">Deluxe Room</option>
                        <option value="Luxury Room">Luxury Room</option>
                        <option value="Guest House">Guest House</option>
                        <option value="Single Room">Single Room</option>
                    </select>
                    <select id="input-group" name="bed_type" style="background: black;">
                        <option value="">Preffered Bed Type</option>
                        <option value="Single">Single</option>
                        <option value="Double">Double</option>
                    </select>
                    <select id="input-group" name="meal_plan" style="background: black;">
                        <option value="">Preffered Meal Plan</option>
                        <option value="Room only">Room only</option>
                        <option value="Breakfast">Breakfast</option>
                        <option value="Half Board">Half Board</option>
                        <option value="Full Board">Full Board</option>
                    </select>
                    <input type="number" id="input-group" name="adult" placeholder="Adult">
                    <input type="number" id="input-group" name="children" placeholder="Children (2-11years)">
                    <input type="number" id="input-group" name="infant" placeholder="Infant (under 2years)">
                </div>

                <div id="input3">

                    <h3 class="text-white">Personal Details</h3>
                </div>


                <div id="input4">

                    <select id="input-group" name="title" style="background: black;">
                        <option value="">Title</option>
                        <option value="Miss.">Miss.</option>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                    </select>
                    <input type="text" id="input-group" name="name" placeholder="Full Name">
                    <input type="number" id="input-group" name="contact" placeholder="Contact Number">
                    <input type="email" id="input-group" name="email" placeholder="Email">
                </div>

                <div id="input5">

                    <span id="input-group" class="text-primary">Nationality</span>
                    <input type="radio" id="input-group" name="nationality" value="Indian" required>
                    <label class="text-white" for="input-group">Indian</label>
                    <input type="radio" id="input-group" name="nationality" value="Non-Indian">
                    <label class="text-white" for="input-group">Non-Indian</label>
                </div>
                <button type="reset" class="btn btn-primary">Clear</button>

                <button type="submit" name="submit" class=" btn btn-warning text-white">Submit</button>

            </div>


        </form>


    </div>
    <br>
    <br>

    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1>ITC Taj Hotel</h1>
                <p>Experience the Best Luxury Lifestyle</p>
            </div>
            <div class="footer-items">
                <h1>Quick Links</h1>
                <div class="border"></div>
                <ul>
                    <a href="index.php">
                        <li>Home</li>
                    </a>
                    <a href="about.php">
                        <li>About</li>
                    </a>
                    <a href="contact.php">
                        <li>Contact</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Important Links</h1>
                <div class="border"></div>
                <ul>

                    <a href="services.php">
                        <li>Services</li>
                    </a>
                    <a href="login.php">
                        <li>Admin</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Contact Us</h1>
                <div class="border"></div>
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                        Taj MG Road, Bengaluru, 41/3, Mahatma Gandhi Rd,
                        Yellappa
                        Garden, Yellappa Chetty Layout, Sivanchetti Gardens, Bengaluru, Karnataka-560001
                    </li><br><br><br><br>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>+91-9779776365</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@itctajbangalore.com</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            Copyright &copy; ITC Taj Bangalore 2021. All rights reserved. Designed by E DEEPA
        </div>
    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>

<?php
$connection = mysqli_connect("localhost","root",""); 
$db = mysqli_select_db($connection,'taj_hotel'); 


if(isset($_POST["submit"])){
      $title=$_POST["title"];
      $name=$_POST["name"];
      $contact=$_POST["contact"];
      $email=$_POST["email"];
      $nationality=$_POST["nationality"];
      $room_type=$_POST["room_type"];
      $bed_type=$_POST["bed_type"];
      $meal_plan=$_POST["meal_plan"];
      $adult=$_POST["adult"];
      $children=$_POST["children"];
      $infant=$_POST["infant"];
      $cin=$_POST["cin"];
      $cout=$_POST["cout"];
      $booking_time=date("Y-m-d H:i:s a");


      $query = "INSERT INTO room_reservation (title,name,contact,email,nationality,room_type,bed_type,meal_plan,adult,children,infant,cin,cout,booking_time) VALUES ('$title','$name','$contact','$email','$nationality','$room_type','$bed_type','$meal_plan','$adult','$children','$infant','$cin','$cout','$booking_time')";
      $query_run = mysqli_query($connection,$query);


if($query_run)
{
   echo "<script type='text/javascript'>alert('Thank You! Your booking is confirmed.');
   window.location='services.php';</script>";
   
}
else
{
    echo '<script> alert("Try Again! Failed to process."); </script>';   
}

}
?>