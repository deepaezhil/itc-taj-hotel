<!DOCTYPE html>

<head>
    <title>Best Star Hotel in India | ITC Taj Hotel</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/team.css">
    <link rel="stylesheet" type="text/css" href="css/gallery.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <style>

    </style>
</head>


<body style="background-color: #22252A;">

    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">ITC Taj Hotel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Admin</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
    </header>


    <div id="demo" class="carousel slide" data-ride="carousel">
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
        </ul>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://www.luxurylifestylemag.co.uk/wp-content/uploads/2017/01/Taj-Bangalore-2.jpg" alt=" "
                    width="1400" height="500">
                <div class="carousel-caption">

                </div>
            </div>
            <div class="carousel-item">
                <img src="https://swearondog.in/wp-content/uploads/2017/08/Vivanta-by-Taj-M-G-Road-.jpg" alt=" "
                    width="1400" height="500">
                <div class="carousel-caption">

                </div>
            </div>
            <div class="carousel-item">
                <img src="https://www.tajhotels.com/content/dam/qmin/Qmin--Website-Banner--Desktop--qmin.png/_jcr_content/renditions/cq5dam.web.1280.1280.png"
                    alt=" " width="1400" height="500">
                <div class="carousel-caption">

                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>

    <section class="team">
        <div class="container">
            <h1>Meet Our Team</h1>
            <div class="card">
                <div class="box">
                    <img src="images/team1.jpg" alt="team img" />
                    <h4>Soundarya Rajan</h4>
                    <h5>Manager</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </div>
            </div>
            <div class="card">
                <div class="box">
                    <img src="images/team2.jpg" alt="team img" />
                    <h4>Krishnappa Swamy</h4>
                    <h5>Assistant Manager</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </div>
            </div>
            <div class="card">
                <div class="box">
                    <img src="images/team3.jpg" alt="team img" />
                    <h4>Vanita Gosh</h4>
                    <h5>Receptionist</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </div>
            </div>
            <div class="card">
                <div class="box">
                    <img src="images/team4.jpg" alt="team img" />
                    <h4>Venkatesh Bhat</h4>
                    <h5>Chief Chef</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </div>
            </div>
        </div>
    </section>
    <br>
    <br>
    <br>
    <br>
    <section class=gallery>
        <h1 style="text-align:center">Slideshow Gallery</h1>
        <div class="container">
            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery1_up.jpg" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery2_up.jpg" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery3_up.jpg" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery4_up.jpg" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery5_up.jpg" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext"></div>
                <img src="images/gallery6_up.jpg" style="width:100%">
            </div>

            <a class="prev" onclick="plusSlides(-1)">❮</a>
            <a class="next" onclick="plusSlides(1)">❯</a>

            <div class="caption-container">
                <p id="caption"></p>
            </div>

            <div class="row">
                <div class="column">
                    <img class="demo cursor" src="images/gallery1.jpg" style="width:100%" onclick="currentSlide(1)"
                        alt="The ITC Taj">
                </div>
                <div class="column">
                    <img class="demo cursor" src="images/gallery2.jpg" style="width:100%" onclick="currentSlide(2)"
                        alt="The ITC Taj">
                </div>
                <div class="column">
                    <img class="demo cursor" src="images/gallery3.jpg" style="width:100%" onclick="currentSlide(3)"
                        alt="The ITC Taj">
                </div>
                <div class="column">
                    <img class="demo cursor" src="images/gallery4.jpg" style="width:100%" onclick="currentSlide(4)"
                        alt="The ITC Taj">
                </div>
                <div class="column">
                    <img class="demo cursor" src="images/gallery5.jpg" style="width:100%" onclick="currentSlide(5)"
                        alt="The ITC Taj">
                </div>
                <div class="column">
                    <img class="demo cursor" src="images/gallery6.jpg" style="width:100%" onclick="currentSlide(6)"
                        alt="The ITC Taj">
                </div>
            </div>
        </div>
    </section>
    <br>
    <br>
    <br>
    <br>

    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1>ITC Taj Hotel</h1>
                <p>Experience the Best Luxury Lifestyle</p>
            </div>
            <div class="footer-items">
                <h1>Quick Links</h1>
                <div class="border"></div>
                <ul>
                    <a href="index.php">
                        <li>Home</li>
                    </a>
                    <a href="about.php">
                        <li>About</li>
                    </a>
                    <a href="contact.php">
                        <li>Contact</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Important Links</h1>
                <div class="border"></div>
                <ul>

                    <a href="services.php">
                        <li>Services</li>
                    </a>
                    <a href="login.php">
                        <li>Admin</li>
                    </a>

                </ul>
            </div>

            <div class="footer-items">
                <h1>Contact Us</h1>
                <div class="border"></div>
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                        Taj MG Road, Bengaluru, 41/3, Mahatma Gandhi Rd,
                        Yellappa
                        Garden, Yellappa Chetty Layout, Sivanchetti Gardens, Bengaluru, Karnataka-560001
                    </li><br><br><br><br>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>+91-9779776365</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@itctajbangalore.com</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            Copyright &copy; ITC Taj Bangalore 2021. All rights reserved. Designed by E DEEPA
        </div>
    </div>

    <script>
    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        captionText.innerHTML = dots[slideIndex - 1].alt;
    }
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>